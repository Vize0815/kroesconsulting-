import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Zap, BarChart3, Users, Lock } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [activeTab, setActiveTab] = useState("system");

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white border-b border-border z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
            The Missing Piece
          </div>
          <div className="hidden md:flex gap-8">
            <a href="#features" className="text-sm text-secondary-foreground hover:text-foreground transition">Funktionen</a>
            <a href="#system" className="text-sm text-secondary-foreground hover:text-foreground transition">System</a>
            <a href="#contact" className="text-sm text-secondary-foreground hover:text-foreground transition">Kontakt</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 md:px-8 relative overflow-hidden">
        {/* Decorative line */}
        <div className="absolute left-0 top-40 w-1 h-64 bg-gradient-to-b from-primary to-transparent opacity-20" />
        
        <div className="container max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          {/* Left: Text */}
          <div className="space-y-8">
            <div className="space-y-4">
              <p className="text-sm font-semibold text-primary uppercase tracking-widest">
                Konfliktmanagement für Führungskräfte
              </p>
              <h1 className="text-5xl md:text-6xl leading-tight text-foreground">
                Das fehlende Puzzleteil
              </h1>
              <p className="text-lg text-secondary leading-relaxed">
                Ein systemischer Ansatz zur Konfliktlösung, der Ihre Führung transformiert. Nicht Feuerwehr-Management – echte Infrastruktur.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button 
                className="bg-primary hover:bg-primary/90 text-white px-8 py-6 text-base font-semibold rounded-sm"
                onClick={() => document.getElementById("system")?.scrollIntoView({ behavior: "smooth" })}
              >
                Zum System <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button 
                variant="outline" 
                className="border-border text-foreground hover:bg-muted px-8 py-6 text-base font-semibold rounded-sm"
              >
                Mehr erfahren
              </Button>
            </div>

            <div className="pt-8 border-t border-border">
              <p className="text-xs text-secondary-foreground uppercase tracking-widest mb-4">Vertraut von</p>
              <div className="flex gap-8 opacity-60">
                <div className="text-sm font-semibold">Leadership Teams</div>
                <div className="text-sm font-semibold">Organisationen</div>
                <div className="text-sm font-semibold">Coaches</div>
              </div>
            </div>
          </div>

          {/* Right: Hero Image */}
          <div className="relative h-96 md:h-full flex items-center justify-center">
            <img 
              src="/manus-storage/hero_image_8d6b6c1f.png"
              alt="The Missing Piece - Red Puzzle"
              className="w-full h-full object-cover rounded-sm"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 md:px-8 bg-card">
        <div className="container max-w-6xl mx-auto">
          <div className="mb-16">
            <p className="text-sm font-semibold text-primary uppercase tracking-widest mb-2">Kernfunktionen</p>
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Ein System, das funktioniert
            </h2>
            <p className="text-lg text-secondary max-w-2xl">
              Das Missing Piece Konfliktlösungssystem ist nicht nur eine Sammlung von Techniken – es ist eine ganzheitliche Infrastruktur für nachhaltiges Konfliktmanagement.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Lock,
                title: "Strukturelle Klarheit",
                description: "Definieren Sie klare Verantwortlichkeiten, Prozesse und Eskalationspfade. Konflikte entstehen oft aus Unklarheit – wir schaffen Transparenz."
              },
              {
                icon: Zap,
                title: "Proaktive Erkennung",
                description: "Lernen Sie, Konflikte früh zu erkennen, bevor sie eskalieren. Ein System zur kontinuierlichen Überwachung und Intervention."
              },
              {
                icon: Users,
                title: "Offene Konfliktkultur",
                description: "Transformieren Sie Konflikte in Chancen. Eine Kultur, die Reibung nicht unterdrückt, sondern konstruktiv nutzt."
              },
              {
                icon: BarChart3,
                title: "Messbare Ergebnisse",
                description: "Verfolgen Sie Fortschritte durch klare Metriken. Sehen Sie, wie sich Teamdynamik, Produktivität und Zufriedenheit verbessern."
              },
              {
                icon: CheckCircle2,
                title: "Nachhaltige Lösungen",
                description: "Nicht nur Symptome bekämpfen. Das System adressiert Wurzeln von Konflikten für langfristige Stabilität."
              },
              {
                icon: ArrowRight,
                title: "Kontinuierliche Entwicklung",
                description: "Feedback-Schleifen und Lernmechanismen, die Ihr System ständig verbessern und anpassen."
              }
            ].map((feature, idx) => (
              <div key={idx} className="p-8 border border-border rounded-sm hover:border-primary transition-colors group">
                <feature.icon className="w-8 h-8 text-primary mb-4 group-hover:scale-110 transition-transform" />
                <h3 className="text-xl font-semibold text-foreground mb-3">{feature.title}</h3>
                <p className="text-secondary leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* System Section */}
      <section id="system" className="py-20 px-4 md:px-8">
        <div className="container max-w-6xl mx-auto">
          <div className="mb-16">
            <p className="text-sm font-semibold text-primary uppercase tracking-widest mb-2">Methodik</p>
            <h2 className="text-4xl md:text-5xl text-foreground mb-4">
              Das Missing Piece System
            </h2>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 mb-12 border-b border-border">
            {[
              { id: "system", label: "Das System" },
              { id: "process", label: "Der Prozess" },
              { id: "results", label: "Die Ergebnisse" }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-4 font-semibold text-sm transition-colors border-b-2 -mb-px ${
                  activeTab === tab.id
                    ? "text-primary border-primary"
                    : "text-secondary border-transparent hover:text-foreground"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              {activeTab === "system" && (
                <>
                  <h3 className="text-3xl font-bold text-foreground">Vier Säulen der Stabilität</h3>
                  <div className="space-y-4">
                    {[
                      { num: "1", title: "Struktur", desc: "Klare Rollen, Prozesse und Verantwortlichkeiten" },
                      { num: "2", title: "Kommunikation", desc: "Transparente Kanäle und regelmäßige Feedback-Schleifen" },
                      { num: "3", title: "Kultur", desc: "Eine Umgebung, die konstruktive Konflikte fördert" },
                      { num: "4", title: "Entwicklung", desc: "Kontinuierliches Lernen und Anpassung" }
                    ].map((item, idx) => (
                      <div key={idx} className="flex gap-4">
                        <div className="w-12 h-12 rounded-sm bg-primary text-white flex items-center justify-center font-bold flex-shrink-0">
                          {item.num}
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{item.title}</h4>
                          <p className="text-secondary text-sm">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {activeTab === "process" && (
                <>
                  <h3 className="text-3xl font-bold text-foreground">Ein iterativer Prozess</h3>
                  <div className="space-y-4">
                    {[
                      { step: "Analyse", desc: "Verstehen Sie die zugrundeliegenden Strukturen und Dynamiken" },
                      { step: "Design", desc: "Entwickeln Sie ein maßgeschneidertes System für Ihre Organisation" },
                      { step: "Implementierung", desc: "Führen Sie das System schrittweise ein und trainieren Sie Teams" },
                      { step: "Monitoring", desc: "Überwachen Sie Fortschritte und passen Sie an" }
                    ].map((item, idx) => (
                      <div key={idx} className="flex gap-4">
                        <div className="w-12 h-12 rounded-sm bg-primary text-white flex items-center justify-center font-bold flex-shrink-0">
                          {String.fromCharCode(65 + idx)}
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground">{item.step}</h4>
                          <p className="text-secondary text-sm">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {activeTab === "results" && (
                <>
                  <h3 className="text-3xl font-bold text-foreground">Messbare Verbesserungen</h3>
                  <div className="space-y-6">
                    {[
                      { metric: "↑ 45%", label: "Verbesserte Teamzufriedenheit" },
                      { metric: "↓ 60%", label: "Weniger eskalierte Konflikte" },
                      { metric: "↑ 35%", label: "Höhere Produktivität" },
                      { metric: "↑ 80%", label: "Bessere Führungskompetenz" }
                    ].map((item, idx) => (
                      <div key={idx} className="border-l-4 border-primary pl-6">
                        <div className="text-3xl font-bold text-primary">{item.metric}</div>
                        <p className="text-secondary text-sm mt-1">{item.label}</p>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>

            <div className="bg-muted p-12 rounded-sm h-96 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl font-bold text-primary/20 mb-4">📊</div>
                <p className="text-secondary">Visuelle Darstellung wird hier angezeigt</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20 px-4 md:px-8 bg-foreground text-white">
        <div className="container max-w-4xl mx-auto text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold">
              Bereit, das fehlende Puzzleteil zu finden?
            </h2>
            <p className="text-lg opacity-90">
              Beginnen Sie heute mit der Transformation Ihres Konfliktmanagements. Ein systemischer Ansatz, der funktioniert.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-8">
            <Button 
              className="bg-white text-foreground hover:bg-gray-100 px-8 py-6 text-base font-semibold rounded-sm"
            >
              Kostenlose Beratung buchen
            </Button>
            <Button 
              variant="outline" 
              className="border-white text-white hover:bg-white/10 px-8 py-6 text-base font-semibold rounded-sm"
            >
              Mehr erfahren
            </Button>
          </div>

          <div className="pt-12 border-t border-white/20">
            <p className="text-sm opacity-75">
              Vertrauen Sie auf ein bewährtes System für nachhaltiges Konfliktmanagement
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card border-t border-border py-12 px-4 md:px-8">
        <div className="container max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            <div>
              <h3 className="font-bold text-foreground mb-4">The Missing Piece</h3>
              <p className="text-secondary text-sm">Konfliktlösungssystem für Führungskräfte</p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4 text-sm">Produkt</h4>
              <ul className="space-y-2 text-sm text-secondary">
                <li><a href="#" className="hover:text-foreground transition">Funktionen</a></li>
                <li><a href="#" className="hover:text-foreground transition">Preise</a></li>
                <li><a href="#" className="hover:text-foreground transition">Dokumentation</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4 text-sm">Unternehmen</h4>
              <ul className="space-y-2 text-sm text-secondary">
                <li><a href="#" className="hover:text-foreground transition">Über uns</a></li>
                <li><a href="#" className="hover:text-foreground transition">Blog</a></li>
                <li><a href="#" className="hover:text-foreground transition">Kontakt</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-4 text-sm">Rechtlich</h4>
              <ul className="space-y-2 text-sm text-secondary">
                <li><a href="#" className="hover:text-foreground transition">Datenschutz</a></li>
                <li><a href="#" className="hover:text-foreground transition">Nutzungsbedingungen</a></li>
                <li><a href="#" className="hover:text-foreground transition">Impressum</a></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-border pt-8 flex flex-col md:flex-row justify-between items-center text-sm text-secondary">
            <p>&copy; 2026 The Missing Piece. Alle Rechte vorbehalten.</p>
            <div className="flex gap-6 mt-4 md:mt-0">
              <a href="#" className="hover:text-foreground transition">Twitter</a>
              <a href="#" className="hover:text-foreground transition">LinkedIn</a>
              <a href="#" className="hover:text-foreground transition">Instagram</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
